from flask import render_template, flash, redirect, url_for
from flask_login import current_user, login_required

from . import public_bp
from app import db, bcrypt
from app.models import Menu
from app.auth.models import User
from app.auth.routes import logout
from .forms import LocationForm, ConfigurationForm


@public_bp.route('/')
def index():
    user = None
    #menu_detail = Menu( name = "Cheese", description = "Cheese pizza is, quite simply, pizza with cheese on it. However, there is more to this classic dish than meets the eye.", price = 249.00, type="pizza")
    #menu_detail1 = Menu( name = "Pepperoni", description = "Pepperoni is one of the most popular pizza toppings. Salty, fatty, and full-flavored, this thinly sliced American salami is typically used", price = 269.00, type="pizza")
    #menu_detail2 = Menu( name = "Hawaiana", description = "It is traditionally topped with pineapple, tomato sauce, cheese, and either ham or bacon.", price = 319.00, type="pizza")
    #menu_detail3 = Menu( name = "Deluxe", description = "A flavourful mix of meat and vegetables, this classic pie will be your go-to for pizza night.", price = 379.00, type="pizza")
    #menu_detail4 = Menu( name = "Vegetariana", description = "Pizza vegetariana consists of a basic pizza dough that is smeared with tomato sauce and topped with mozzarella and a combination of fresh, seasonal vegetables, typically zucchini, eggplants, and peppers, which are almost always pre-cooked.", price = 369.00, type="pizza")
    #db.session.add(menu_detail)
    #db.session.add(menu_detail1)
    #db.session.add(menu_detail2)
    #db.session.add(menu_detail3)
    #db.session.add(menu_detail4)
    #db.session.commit()
    menu = Menu.query.filter_by(type='pizza').all()
    if current_user.is_authenticated:
        user = current_user

    return render_template('public/index.html', current_user = user, menu = menu)


@public_bp.route('/menu')
def menu():
    user = None
    menu = Menu.query.filter_by(type='pizza').all()
    prices = {product.name : Menu.query.filter_by(name=product.name).first().price for product in menu}

    if current_user.is_authenticated:
        user = current_user
    return render_template('public/menu.html', current_user = user, menu = menu, prices=prices)
    #return render_template(menu)


@public_bp.route('/complements')
def complements():
    user = None
    menu = Menu.query.filter_by(type='drink').all()
    menu += Menu.query.filter_by(type='complement').all()
    prices = {k.name : Menu.query.filter_by(name=k.name).first().price for k in menu}

    if current_user.is_authenticated:
        user = current_user

    return render_template('public/complements.html', current_user = user, menu = menu, prices=prices)


@public_bp.route('/about')
def about():
    return render_template('public/about.html')


@public_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    user = current_user
    location_form = LocationForm()
    configuration_form = ConfigurationForm()

    if location_form.submit.data and location_form.validate():
        user.street = location_form.street.data
        user.house_number = location_form.house_number.data
        user.zip_code = location_form.zip_code.data
        user.phone_number = location_form.phone_number.data
        db.session.add(user)
        db.session.commit()
        flash('Profile successfully updated', 'dark')

    elif configuration_form.submit.data and configuration_form.validate():
        name = configuration_form.name.data
        email = configuration_form.email.data
        password = configuration_form.password.data

        if user.name == name and user.email == email and password == '':
            flash('No data has been modified, please check your changes.', 'warning')
            return redirect(url_for('public.profile'))

        elif User.query.filter_by(email = email).first() and user.email != email:
            flash(f'Email {email} is already in use, please select another.', 'warning')
            return(redirect(url_for('public.profile')))

        else:
            user.name = user.name if name == '' else name
            user.email = user.email if email == '' else email
            user.password = user.password if password == '' else bcrypt.generate_password_hash(password)
            db.session.add(user)
            db.session.commit()
            logout()
            flash('Correctly updated data (Blank fields will be kept with the same data.)', 'dark')
            return redirect(url_for('public.index'))

    return render_template('public/profile.html', current_user=user, location_form=location_form, configuration_form=configuration_form)