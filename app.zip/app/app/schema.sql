DROP TABLE IF EXISTS menu;
DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS sell;

CREATE TABLE menu (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    pizza_name TEXT NOT NULL,
    pizza_description TEXT NOT NULL,
    price FlOAT NOT NULL,
    pizza_type TEXT NOT NULL
);

CREATE TABLE sell (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER NOT NULL,
    sell_number TEXT NOT NULL,
    date_ date NOT NULL,
    final_price FlOAT NOT NULL
);

CREATE TABLE user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_name String(64) NOT NULL,
    email String(256) UNIQUE NOT NULL,
    password_ String(128) NOT NULL,
    zip_code TEXT NOT NULL,
    phone_number String(10) NOT NULL,
    street String(80) NOT NULL,
    house_number String(10) NOT NULL
);

