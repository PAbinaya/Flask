from flask import Flask, render_template
from flask_bcrypt import Bcrypt
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

from .config import DevelopmentConfig, ProductionConfig


db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()


def register_error_handlers(app):
    @app.errorhandler(500)
    def base_error_handler(e):
        return render_template('500.html'), 500
    @app.errorhandler(404)
    def error_404_handler(e):
        return render_template('404.html'), 404


def create_app():
    app = Flask(__name__)
    app.config.from_object(DevelopmentConfig)

    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)

    with app.app_context():
        from .models import Menu, Sell, User
        db.create_all()
        menu_detail = Menu( name = "Cheese", description = "Cheese pizza is, quite simply, pizza with cheese on it. However, there is more to this classic dish than meets the eye.", price = 249.00, type="pizza")
        menu_detail1 = Menu( name = "Pepperoni", description = "Pepperoni is one of the most popular pizza toppings. Salty, fatty, and full-flavored, this thinly sliced American salami is typically used", price = 269.00, type="pizza")
        menu_detail2 = Menu( name = "Hawaiana", description = "It is traditionally topped with pineapple, tomato sauce, cheese, and either ham or bacon.", price = 319.00, type="pizza")
        menu_detail3 = Menu( name = "Deluxe", description = "A flavourful mix of meat and vegetables, this classic pie will be your go-to for pizza night.", price = 379.00, type="pizza")
        menu_detail4 = Menu( name = "Vegetariana", description = "Pizza vegetariana consists of a basic pizza dough that is smeared with tomato sauce and topped with mozzarella and a combination of fresh, seasonal vegetables, typically zucchini, eggplants, and peppers, which are almost always pre-cooked.", price = 369.00, type="pizza")
        db.session.add(menu_detail)
        db.session.add(menu_detail1)
        db.session.add(menu_detail2)
        db.session.add(menu_detail3)
        db.session.add(menu_detail4)
        db.session.commit()

    from .public import public_bp
    from .auth import auth_bp
    from .cart import cart_bp
    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(cart_bp)

    register_error_handlers(app)

    return app


app = create_app()
