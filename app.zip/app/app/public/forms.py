from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField 
from wtforms.validators import DataRequired, Email, Length


class LocationForm(FlaskForm):
    street = StringField('Street', validators=[DataRequired(), Length(max=80)])
    house_number = StringField('House number', validators=[DataRequired(), Length(max=10)])
    zip_code = StringField('Zip code', validators=[DataRequired(), Length(min=5, max=5)])
    phone_number = StringField('Phone number', validators=[DataRequired(), Length(min=10)])
    submit = SubmitField('Save')


class ConfigurationForm(FlaskForm):
    name = StringField('Name')
    email = StringField('Email', validators=[Email()])
    password = PasswordField('Password')
    submit = SubmitField('Save')